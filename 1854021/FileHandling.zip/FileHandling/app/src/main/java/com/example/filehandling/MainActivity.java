package com.example.filehandling;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity
{
    Button write,append,clear,read;
    EditText e;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        formLoad();
    }
    public void formLoad()
    {
        e = findViewById(R.id.editText2);
        write = findViewById(R.id.btn_write);
        read = findViewById(R.id.btn_read);
        append = findViewById(R.id.btn_append);
        clear = findViewById(R.id.btn_clr);

        write.setOnClickListener
                (
                        new View.OnClickListener()
                        {
                            @Override
                            public void onClick(View v)
                            {
                                if(checkPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE))
                                {
                                    try
                                    {
                                        /***********  write to internal storage *************/
                                        String input = e.getText().toString();
                                    /*FileOutputStream fileOutputStream = openFileOutput("Demo.txt",MODE_PRIVATE);
                                    fileOutputStream.write(input.getBytes());
                                    fileOutputStream.close();*/
                                        /************** write to external storage ************/
                                        File myFile = new File(Environment.getExternalStorageDirectory(),"Demo.txt");
                                        myFile.createNewFile();
                                        FileOutputStream fileOutputStream = new FileOutputStream(myFile);
                                    /*OutputStreamWriter myOutWriter = new OutputStreamWriter(fOut);
                                    myOutWriter.write(e.getText().toString());
                                    myOutWriter.close();*/
                                        fileOutputStream.write(input.getBytes());
                                        fileOutputStream.close();
                                        Toast.makeText(getApplicationContext(),"Contents written successfully",Toast.LENGTH_SHORT);
                                    }
                                    catch (FileNotFoundException e1)
                                    {
                                        Toast.makeText(getApplicationContext(),""+e1,Toast.LENGTH_SHORT);
                                    }
                                    catch (Exception e)
                                    {
                                        Toast.makeText(getApplicationContext(),""+e,Toast.LENGTH_SHORT);
                                    }
                                }

                            }
                        }
                );
        read.setOnClickListener
                (
                        new View.OnClickListener()
                        {
                            @Override
                            public void onClick(View v)
                            {
                                try
                                {
                                    /************* Read internal storage file ****************/
                                    /*InputStreamReader inputStreamReader = new InputStreamReader(openFileInput("Demo.txt"));
                                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                                    e.setText(bufferedReader.readLine());
                                    bufferedReader.close();
                                    inputStreamReader.close();*/

                                    /************ Read external storage file **************/
                                    File myFile = new File(Environment.getExternalStorageDirectory(),"Demo.txt");
                                    FileInputStream fileInputStream = new FileInputStream(myFile);
                                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));
                                    e.setText(bufferedReader.readLine());
                                    bufferedReader.close();
                                    fileInputStream.close();
                                }
                                catch (Exception e)
                                {
                                    Toast.makeText(getApplicationContext(),""+e,Toast.LENGTH_SHORT);
                                }
                            }
                        }
                );
        append.setOnClickListener
                (
                        new View.OnClickListener()
                        {
                            @Override
                            public void onClick(View v)
                            {
                                if(checkPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE))
                                {
                                    try
                                    {
                                        String input = e.getText().toString();
                                    /*FileOutputStream fileOutputStream = openFileOutput("Demo.txt",MODE_APPEND);
                                    fileOutputStream.write(input.getBytes());
                                    fileOutputStream.close();*/
                                        /************** write to external storage ************/
                                        File myFile = new File(Environment.getExternalStorageDirectory(),"Demo.txt");
                                        myFile.createNewFile();
                                        FileOutputStream fileOutputStream = new FileOutputStream(myFile);
                                    /*OutputStreamWriter myOutWriter = new OutputStreamWriter(fOut);
                                    myOutWriter.append(e.getText().toString());
                                    myOutWriter.close();*/
                                        fileOutputStream.write(input.getBytes());
                                        fileOutputStream.close();
                                        Toast.makeText(getApplicationContext(),"Contents appended successfully",Toast.LENGTH_SHORT);
                                    }
                                    catch (Exception e)
                                    {
                                        Toast.makeText(getApplicationContext(),""+e,Toast.LENGTH_SHORT);
                                    }
                                }
                            }
                        }
                );
        clear.setOnClickListener
                (
                        new View.OnClickListener()
                        {
                            @Override
                            public void onClick(View v)
                            {
                                e.setText("");
                            }
                        }
                );


    }
    public boolean checkPermission(String permission)
    {
        int check = ContextCompat.checkSelfPermission(this, permission);
        return (check == PackageManager.PERMISSION_GRANTED);
    }
}
