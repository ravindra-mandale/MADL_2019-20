package edu.ritindia.sendsms_exp7;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button send;
    TextView incoming;
    private  final  static int REQUEST_SMS=2;
    final SmsManager sms = SmsManager.getDefault();

    private BroadcastReceiver mIncomingSMSrecierver = new BroadcastReceiver() {
        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bundle = intent.getExtras();
            Object o[] = (Object[])bundle.get("pdus");
            SmsMessage smsMessage = SmsMessage.createFromPdu((byte[])(o[0]));
            String address = smsMessage.getOriginatingAddress();
            String msg = smsMessage.getMessageBody();
            int id = sms.getSubscriptionId();
            incoming.setText("Sender:"+address+" Message:"+msg+" Subscription id:"+id);
            Log.d("msg","Address: "+address+" Message: "+msg+" Subscription id: "+id);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        send = findViewById(R.id.send_btn);
        incoming = findViewById(R.id.incoming_tv);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendSMS();
            }
        });
        IntentFilter filter = new IntentFilter(Telephony.Sms.Intents.SMS_RECEIVED_ACTION);
        registerReceiver(mIncomingSMSrecierver, filter);
    }
    private  void sendSMS()
    {
        if(ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS)!= PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.SEND_SMS},REQUEST_SMS);
        }
        else
        {
            SmsManager smsManager= SmsManager.getDefault();
            smsManager.sendTextMessage("+918208862782","+919689522590","Sending message for debugging application",null,null);
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode== REQUEST_SMS)
        {
            if(grantResults.length>0 && grantResults[0]== PackageManager.PERMISSION_GRANTED)
            {
                sendSMS();
            }
            else
            {
                Toast.makeText(getApplicationContext(),"Permissino rejected",Toast.LENGTH_LONG).show();
            }
        }
    }
}
